<?php
session_start();

$extensoes = array();

$extensoes['pdo'] = extension_loaded('PDO');
$extensoes['pdo_mysql'] = extension_loaded('pdo_mysql');
$extensoes['zip'] = extension_loaded('zip');
$extensoes['xmlrpc'] = extension_loaded('xmlrpc');



?>
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
  <style type="text/css">
    .extension_no {
      background-color: red;
    }

    .extension_ok {
      background-color: green;
    }
  </style>
</head>

<body>
  <div>
    ViaSW - WebService de integra&ccedil;&atilde;o
  </div>

  <?php
  if (!isset($_GET['fase'])) {

  ?>
    <div>
      Verificando extens&otilde;es do PHP...
    </div>
    <?php
    foreach ($extensoes as $key => $value) {
      if ($value) {
        $class = 'extension_ok';
        $check = 'OK';
      } else {
        $class = 'extension_no';
        $check = 'N&atilde;o OK';
      }
      echo "<div class='$class'>Extens&atilde;o $key: $check<br></div>";
    }

    if ($class == 'extension_ok') {
      echo "<form action='index.php?fase=2' method='post'>";
      echo "Caminho da instala&ccedil;&atilde;o:<br><input type='text' name='caminho' id='caminho'>";
      echo "<input type='submit'></input>";
    }
  } elseif ($_GET['fase'] == '2') {
    if (isset($_POST['caminho'])) {
      if (is_dir($_POST['caminho'])) {
        $zip = new ZipArchive();
        $zip->open('viasw.zip');
        $ret = $zip->extractTo($_POST['caminho']);
        $zip->close();
        if ($ret) {
          $_SESSION['caminho'] = $_POST['caminho'] . DIRECTORY_SEPARATOR . "viasw";
          echo "Arquivo extraido com sucesso.";
          echo "<form action='index.php?fase=3' method='post'>";
          echo "<input type='submit' name='proximo'></input>";
        } else {
          echo "Erro ao extrair arquivo";
        }
      } else {
        echo "Não é um caminho valido: " . $_POST['caminho'];
      }
    }
  } elseif ($_GET['fase'] == '3') {
    ?>
    <form action='index.php?fase=4' method="post">
      Servidor: <input type="text" name="servidor" /> <br />
      Banco: <input type="text" name="banco" /><br />
      Usuario: <input type="text" name="usuario" /><br />
      Senha: <input type="password" name="senha" /><br />
      Caminho para salvar as fotos: <input type="text" name="fotos" /><br />
      URL das fotos: <input type="text" name="url" /><br />
      <input type="submit" />
    </form>
    ATEN&Ccedil;&Atilde;O: O banco de dados j&aacute; deve existir no servidor.
    <?php
  } elseif ($_GET['fase'] == '4') {
    $arquivo = $_SESSION['caminho'] . DIRECTORY_SEPARATOR . 'config';

    $config = simplexml_load_file($arquivo);
    $config->dbconfig->dbuser = (string)$_POST['usuario'];
    $config->dbconfig->dbserver = $_POST['servidor'];
    $config->dbconfig->dbname = $_POST['banco'];
    $config->dbconfig->dbpassword = $_POST['senha'];
    $config->fotoconfig->pathfotos = $_POST['fotos'];
    $config->urlfotos = $_POST['url'];

    $geraXml = $config->asXML($_SESSION['caminho'] . DIRECTORY_SEPARATOR . 'config.xml');

    $conn;
    try {
      $conn_str = "mysql:host=" . $config->dbconfig->dbserver . ";dbname=" . $config->dbconfig->dbname . ";charset=utf8";
      $conn = new PDO($conn_str, $config->dbconfig->dbuser, $config->dbconfig->dbpassword);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, 0);
      //$conn->setAttribute(PDO::ATTR_FETCH_TABLE_NAMES, false);
      //$conn->exec('SET CHARACTER SET utf8');
      $conn->setAttribute(PDO::ATTR_FETCH_TABLE_NAMES, true);
    } catch (PDOException $ex) {
      die("Não foi possível conectar ao banco de dados");
    }

    $file = $_SESSION['caminho'] . DIRECTORY_SEPARATOR . "DB" . DIRECTORY_SEPARATOR . "viasw.sql";

    if ($file = file_get_contents($file)) {
      foreach (explode(";", $file) as $query) {
        $query = trim($query);

        try {
          if (!empty($query) && $query != ";") {
            $conn->exec($query);
          }
        } catch (Exception $e) {
          echo 'Exception -> ';
          var_dump($e->getMessage());
          die();
        }
      }
    }

    if ($geraXml) {
    ?>
      Configura&ccedil;&atilde;o gerada com sucesso. <br />
      Instala&ccedil;&atilde;o encerrada.
  <?php
    }
    // file_put_contents($_SESSION['caminho'].'\config.xml', print_r($xml,true));
  }
  ?>
</body>

</html>